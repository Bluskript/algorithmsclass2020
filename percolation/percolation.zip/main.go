package main

import (
	"fmt"
)

func main() {
	stats := NewPercolationStats(8, 1)
	fmt.Printf("mean: %f \nstddev: %f \nconfidenceLow: %f \ncondidenceHigh: %f\n",
		stats.mean,
		stats.stddev,
		stats.confidenceLow,
		stats.confidenceHigh,
	)
}
